tmux kill-server
rm -rf worktree*
rm -rf ~/.claude-squad
